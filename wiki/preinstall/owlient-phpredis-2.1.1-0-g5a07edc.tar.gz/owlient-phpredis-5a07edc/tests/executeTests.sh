#!/bin/sh

phpunit Redis_Test ./TestRedis.php
