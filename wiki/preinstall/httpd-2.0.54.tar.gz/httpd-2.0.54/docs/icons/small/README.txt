
These icons are provided as an alternative to the standard Apache
icon graphics.  All graphics in this directory, with the exception
of rainbow.gif, are 16x16 pixels in size, rather than the 20x22
dimension icons which are the normal defaults for Apache and are
in the parent directory of this one.
