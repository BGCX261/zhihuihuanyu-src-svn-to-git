<?php
/*
 * Copyright (c) 2012, sina mobile sms.
 * All rights reserved.
 * file	name		cmp_smsd_svr_htdocs.php
 * description		��������Ϊcronִ�С����ڱȽϸ�̨����smsd��svrģ��ʹ�õ�ҵ������Ƿ�һ�¡�
 * 					��Ҫ������ʽ��Ⱥ�е�����һ̨���û���������smsd-svr-htdocs���롣Ŀǰ����111.13.53.111
 *  					
 * usage: 
 * 		�κ��û����ɣ�ÿ10��������һ�Σ����磺
 * 		/data1/smsd/10668888/1/php/bin/php -q /data1/smsd/watch/cmp_smsd_svr_htdocs.php /data1/smsd/10668888/1/svr/htdocs/ cm >> /data1/smsd/watch/cmp_smsd_svr_htdocs.php.cm.log 2>&1
 * 
 * date			author		changes
 * 2012-11-01	gumeng		 ����Ի����뾭�����в��ԣ��������������ϲ�һ�£��ʲ��Ի����ܲ������һ���Լ�顣
 * 				
 * 				o ֻ�ܶ��ѷ���ok�Ĵ�����м�顣���ܶ�δ�����Ĵ�����м�顣
 * 				���ڴ���δ������ԭ�򣬱������޷���֪��
 * 				���ڴ�webǰ��������һ̨��ʽ���ύ��ʧ�ܵĸ���̫�ͣ��ʶ���δ�����Ĵ��룬����һ���Լ�顣
 * 
 * 				o ��̨��ʽ��֮����Ҫ���д���һ���Լ�飬��֤����̨��һ�µġ�
 * 
 * 2012-10-11	gumeng		create
 */

$smsd_type_list = array('cm', 'cu', 'ct');

if($argc != 3 || !is_dir($argv[1]) || !in_array($argv[2], $smsd_type_list)) {
	echo "cmd err: $argv[0] local_smsd_svr_htdocs_path smsd_type[cm|cu|ct]\n";
	echo "eg: $argv[0] /data0/smsd_svr/wb/1/svr/htdocs/ cm\n";
	echo "where smsd_type means cm=chine-mobile, cu=china-unicom, ct=china-tele, etc\n";
	exit();
}

$root = '/data1/smsd/watch/';
$log = $root.'log/';
$local_smsd_svr_htdocs_path = $argv[1];
$smsd_type = $argv[2];
$local_machine = '��ʽ��53.111,����Ϊ'.$smsd_type;

// ��ʼ
$start_time = get_microtime();


$mobile = array('15801564398', '13910267935', '13701308816','18810492519', '13811400944');
$mail_to_arr = array('mengmeng3@staff.sina.com.cn', 'dianchun@staff.sina.com.cn', 'yunlong@staff.sina.com.cn',
				'jingchen@staff.sina.com.cn', 'guangqiao@staff.sina.com.cn');

/*
$mobile = array('15801564398');
$mail_to_arr = array('mengmeng3@staff.sina.com.cn');
*/

$logfile = $log.'cmp.svr.'.date('Ymd').'.log';

mylog($logfile, 'ok.'.$smsd_type, 'program start.');

$smsdergod = array(
	'cm' => array(
		'wb.190.33'=>array('url'=>'http://172.16.190.33:8612/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/1/svr/htdocs'),
		'wb.190.34'=>array('url'=>'http://172.16.190.34:8612/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/1/svr/htdocs'),
		'wb.53.110'=>array('url'=>'http://172.16.38.110:8612/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/1/svr/htdocs'),
		'wb.53.111'=>array('url'=>'http://172.16.38.111:8612/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/1/svr/htdocs'),
		'web.37.74'=>array('url'=>'http://10.55.17.74/smsdweb/wbnew/1/smsdergod.php', 'path'=>'/data0/smsd_svr/wb/1/svr/htdocs')),

	'cu' => array(
		'wb.190.33'=>array('url'=>'http://172.16.190.33:8622/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/2/svr/htdocs'),
		'wb.190.34'=>array('url'=>'http://172.16.190.34:8622/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/2/svr/htdocs'),
		'wb.53.110'=>array('url'=>'http://172.16.38.110:8622/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/2/svr/htdocs'),
		'wb.53.111'=>array('url'=>'http://172.16.38.111:8622/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/2/svr/htdocs'),
		'web.37.74'=>array('url'=>'http://10.55.17.74/smsdweb/wbnew/2/smsdergod.php', 'path'=>'/data0/smsd_svr/wb/2/svr/htdocs')),

	'ct' => array(
		'wb.190.33'=>array('url'=>'http://172.16.190.33:8632/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/3/svr/htdocs'),
		'wb.190.34'=>array('url'=>'http://172.16.190.34:8632/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/3/svr/htdocs'),
		'wb.53.110'=>array('url'=>'http://172.16.38.110:8632/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/3/svr/htdocs'),
		'wb.53.111'=>array('url'=>'http://172.16.38.111:8632/smsdergod/smsdergod.php', 'path'=>'/data1/smsd/10668888/3/svr/htdocs'),
		'web.37.74'=>array('url'=>'http://10.55.17.74/smsdweb/wbnew/3/smsdergod.php', 'path'=>'/data0/smsd_svr/wb/3/svr/htdocs')),
);

$db_info = array(
	'cm' => array('host'=>"mft2.db.intra.mobile.sina.cn:3308", 'user'=>"smsdweb", 'pwd'=>"0x1MFC2m", 'db'=>'smsd_weibo_1'),
	'cu' => array('host'=>"mft2.db.intra.mobile.sina.cn:3308", 'user'=>"smsdweb", 'pwd'=>"0x1MFC2m", 'db'=>'smsd_weibo_2'),
	'ct' => array('host'=>"mft2.db.intra.mobile.sina.cn:3308", 'user'=>"smsdweb", 'pwd'=>"0x1MFC2m", 'db'=>'smsd_weibo_3'),
);

// ��ȡδ������ָ���б������б�������ָ��һ���Լ��
$target_db = $db_info[$smsd_type];
$conn=@mysql_connect($target_db['host'], $target_db['user'], $target_db['pwd']);
if(false===$conn) {
	$sms_msg = "svr.cmp.err:��[{$local_machine}]������web.dbʧ�ܣ����޷�����ָ��һ���Լ�顣�ٲ飺";
	$mail_msg = $sms_msg.mysql_error();
	send_flat_mail($mail_to_arr, $local_machine.'.smsd.svr.cmp.err', $mail_msg, '');
	sendsms($logfile, $sms_msg, $mobile);
	mylog($logfile, 'error'.$smsd_type, $mail_msg);
	exit;
}
@mysql_select_db($target_db['db']);
$sql = "select * from sw_cmd  where c_flag=1";
$result=@mysql_query($sql); 
if(false===$result) {
	$sms_msg = "svr.cmp.err:��[{$local_machine}]�ϲ�ѯweb.dbʧ�ܣ����޷�����ָ��һ���Լ�顣�ٲ飺";
	$mail_msg = $sms_msg.mysql_error();
	send_flat_mail($mail_to_arr, $local_machine.'.smsd.svr.cmp.err', $mail_msg, '');
	sendsms($logfile, $sms_msg, $mobile);
	mylog($logfile, 'error'.$smsd_type, $mail_msg);
	exit;
}
$unpub_list = array();
while($row=@mysql_fetch_array($result, MYSQL_ASSOC)) {
	$one_unpub = array();
	$one_unpub['lcode'] = $row['c_up_receiver'];
	$one_unpub['title'] = $row['c_title'];
	$one_unpub['cmd'] = $row['c_up_command'];
	$one_unpub['who'] = $row['c_who'];
	$one_unpub['when'] = $row['c_when'];
	
	$unpub_list[] = $one_unpub;
}
@mysql_free_result($result);
@mysql_close($conn);
if( count($unpub_list)>0 ) {
	$msg = "δ������ָ� ".count($unpub_list)." �����ٲ飺";
	mylog($logfile, 'error.'.$smsd_type, $msg);
	echo $msg;
	print_r($unpub_list);
}

// ��ʼһ���Լ��
$t = array();
ergod_dir($local_smsd_svr_htdocs_path, $t);
array_key2str($t, $r);
/*
 * $r like:
 * Array
(
    [/106901953/01001/002/_default.php] => 821801e6c8941d16c0b02ca089842f96
    [/106901953/01001/_default.php] => 47c80d0888c7fb52a594b3b2aca0890c
)
 */

$target_smsd = $smsdergod[$smsd_type];

foreach($target_smsd as $host=>$host_info) {
	
	$start_time_one_smsd = get_microtime();
	$ok = true;
	
	$url = $host_info['url'].'?smsd_svr_htdocs='.$host_info['path'];
	$ret = file_get_contents($url);

	$a = array();
	array_key2str( unserialize($ret) , $a);

	$result1 = array_diff_key($r, $a);
	$result2 = array_diff_key($a, $r);
	$result3 = array_diffvalue_samekey($a, $r);

	// ����webǰ�˻�37.74�Ƚ�ʱ����Ҫ��δ�����Ĳ˵����ˣ�����������ʽ�����Ƚ�ʱ��Ӧ�ö����д�����м�顣
	if(false !== strpos($host, 'web')) {
		$result1 = trim_unpub_list($result1, $unpub_list);
		$result2 = trim_unpub_list($result2, $unpub_list);
		$result3 = trim_unpub_list($result3, $unpub_list);
	}
	//print_r($result1);
	//print_r($result2);
	//print_r($result3);
	//exit;
	
	$sms_msg = '';
	$mail_msg = '';
	if(count($result1) > 0)
	{
		$ok = false;
		$sms_msg = "svr.cmp.err:��[{$local_machine}]���У�������[{$host}]��û�е�ָ� ".count($result1)." �����ٲ�:";
		$mail_msg = $sms_msg.implode(", ", array_keys($result1) );

		send_flat_mail($mail_to_arr, $local_machine.'.smsd.svr.cmp.err', $mail_msg, '');
		sendsms($logfile, $sms_msg, $mobile);

		echo $sms_msg."\n";
		print_r($result1);
	}
	$runtime = get_microtime() - $start_time_one_smsd;
	if($mail_msg != '') {
		mylog($logfile, 'error.'.$smsd_type, $mail_msg.". time used:".$runtime);
	}

	$sms_msg = '';
	$mail_msg = '';
	if(count($result2) > 0)
	{
		$ok = false;
		$sms_msg = "svr.cmp.err:��[{$host}]���У�������[{$local_machine}]��û�е�ָ� ".count($result2)." �����ٲ�:";
		$mail_msg = $sms_msg.implode(", ", array_keys($result2) );

		send_flat_mail($mail_to_arr, $local_machine.'.smsd.svr.cmp.err', $mail_msg, '');
		sendsms($logfile, $sms_msg, $mobile);

		echo $sms_msg."\n";
		print_r($result2);
	}
	$runtime = get_microtime() - $start_time_one_smsd;
	if($mail_msg != '') {
		mylog($logfile, 'error.'.$smsd_type, $mail_msg.". time used:".$runtime);
	}
	
	$sms_msg = '';
	$mail_msg = '';
	if(count($result3) > 0)
	{
		$ok = false;
		$sms_msg = "svr.cmp.err:��[{$local_machine}]��[{$host}]�Ͼ��У�����md5_fileֵ��һ�µ�ָ� ".count($result3)." �����ٲ�:";
		$mail_msg = $sms_msg.implode(", ", array_keys($result3) );

		send_flat_mail($mail_to_arr, $local_machine.'.smsd.svr.cmp.err', $mail_msg, '');
		sendsms($logfile, $sms_msg, $mobile);

		echo $sms_msg."\n";
		print_r($result3);
	}
	$runtime = get_microtime() - $start_time_one_smsd;
	if($mail_msg != '') {
		mylog($logfile, 'error.'.$smsd_type, $mail_msg.". time used:".$runtime);
	}
	
	if($ok) {
		mylog($logfile, 'ok.'.$smsd_type, "$host cmp ok. time used:".$runtime);
	}
}

$runtime = get_microtime() - $start_time;	
mylog($logfile, 'ok.'.$smsd_type, 'program end. time used:'.$runtime);

// ȥ��$src�е�δ����ָ��
function trim_unpub_list($src, $unpub_list)
{	
	$trimed_src  = array();
	foreach($src as $one_src=>$one_md5) {
		$ret = get_lcode_cmd($one_src);
		$find = false;
		foreach($unpub_list as $one_unpub) {
			if($ret['lcode'] == $one_unpub['lcode'] && $ret['cmd'] == $one_unpub['cmd']) {
				$find = true;
				break;
			}
		}
		if(false === $find) {
			$trimed_src[$one_src] = $one_md5;	
		}
	}
	
	return $trimed_src;
}

// src like: /10690090/3/_default.php
function get_lcode_cmd($src)
{
	$ret = array('lcode'=>'', 'cmd'=>'');
	
	$idx = strripos($src, "/");
	if(false === $idx) {
		return $ret;
	}
	
	$tmp = explode("/", substr($src, 0, $idx)); // like: /10690090/3
	$ret['lcode'] = implode('', $tmp);
	
	$tmp = substr($src, $idx + 1); // like: _default.php
	$idx = strripos($tmp, ".");
	$ret['cmd'] = substr($tmp, 0, $idx);
	if($ret['cmd'] == '_default') {
		$ret['cmd'] = '*';
	}
	
	return $ret;
}

function ergod_dir($dir, &$a)
{
        if(!is_dir($dir))
                return ;

        $d = dir($dir);
        while (false !== ($entry = $d->read())) 
        {
                if($entry == '.' || $entry == '..')
                        continue;

                if(is_dir($dir.'/'.$entry))
                {
                        ergod_dir($dir.'/'.$entry, $a[$entry]);
                }
                else
                {
                        $a[$entry] = md5_file($dir.'/'.$entry);
                }
        }
        $d->close();
} 

function array_key2str($array, &$ret, $pre='')
{
	foreach($array as $k=>$v)
	{
		if(is_array($v))
		{
			array_key2str($v, $ret, $pre.'/'.$k);
		}
		else
		{
			$ret[$pre.'/'.$k] = $v;
		}
	}
}

function array_diffvalue_samekey($array1, $array2)
{
	$ret = array();
	foreach($array1 as $k=>$v)
	{
		if(isset($array2[$k]) && $v != $array2[$k]) 
		{
			$ret[$k] = $v;
		}
	}
	
	return $ret;
}


/**
 * @desc	log
 * @param	$data: infos without \n
 * @return	null
 */
function mylog($logfile, $phpfilename, $data)
{
	$fp = fopen($logfile,'a');
	if($fp===false) {
		return;
	}
	if (!flock($fp, LOCK_EX)) { // do an exclusive lock
		fclose($fp);		
		return;
	}else {
		$data = '['.date("Y-m-d H:i:s").']`'.$phpfilename.'`'.$data."\n";
		fwrite($fp, $data);
	    flock($fp, LOCK_UN); // release the lock
		fclose($fp);
	}	
}

function get_microtime()
{
	list($usec, $sec) = explode(" ",microtime());
	return ((float)$usec + (float)$sec);
}

function sendsms($logfile, $msg, $mobile)
{
	$msg = rawurlencode($msg);
	
	foreach($mobile as $one_mobile) {
		$url = "http://inno.smsinter.sina.com.cn/cgi-bin/internal/pushsm_ne?suser=sinasms&spwd=test&id=103463&msg=${msg}&rcvm=${one_mobile}&lcode=10668888&ver=1&from=1234";
		$res = trim(file_get_contents($url));
		mylog($logfile, 'sendsms', 'ret='.$res.'`url='.$url);
	}
}

function send_flat_mail($to_arr, $subject, $msg, $headers='')
{
	foreach($to_arr as $one_dest) {
		mail($one_dest,$subject,$msg,$headers);		
	}
}
?>
