<?php
/*
 * Copyright (c) 2012, sina mobile sms.
 * All rights reserved.
 * file	name		smsdergod.php
 * description		��������Ϊsmsd.moģ��Ľӿڣ����ڽ������ϵ�smsd-svr-htdocs�µ������ļ�����md5ȡֵ��
 * 					Ȼ��������л���Ȼ�󷵻����л����ֵ��
 * 
 * date			author		changes
 * 2012-10-11	gumeng		��Ϊ��ȡmd5�ķ�ʽ
 */

$ip_white_list = array('10.55.17.74', '172.16.190.33', '172.16.190.34', '172.16.38.110', '172.16.38.111');

$ip = $_SERVER["REMOTE_ADDR"];
if(!in_array($ip, $ip_white_list)) {
	echo "$ip is denied!";
	exit;
}
$smsd_svr_htdocs  = $_GET['smsd_svr_htdocs'];
if($smsd_svr_htdocs == '') {
	echo "args is NULL";
	exit;
}
if(!is_dir($smsd_svr_htdocs)) {
	echo "$smsd_svr_htdocs is NOT dir";
	exit;
}

$dir = $smsd_svr_htdocs; // like: '/data1/smsd/10668888/1/svr/htdocs';

$r = array();
ergod_dir($dir, $r);

//print_r($r);
echo serialize($r);

function ergod_dir($dir, &$a)
{
        if(!is_dir($dir))
                return ;

        $d = dir($dir);
        while (false !== ($entry = $d->read())) 
        {
                if($entry == '.' || $entry == '..')
                        continue;

                if(is_dir($dir.'/'.$entry))
                {
                        ergod_dir($dir.'/'.$entry, $a[$entry]);
                }
                else
                {
                        $a[$entry] = md5_file($dir.'/'.$entry);
                }
        }
        $d->close();
} 
?>
