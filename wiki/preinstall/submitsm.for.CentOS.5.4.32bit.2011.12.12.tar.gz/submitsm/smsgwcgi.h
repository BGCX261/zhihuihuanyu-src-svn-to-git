#ifndef _SMSCGI_CLNT_H
#define	_SMSCGI_CLNT_H


#define MISC_OK				0	//�ɹ�
#define MISC_CONNECT_ERR	-100 //������վ��ַ����
#define MISC_HTTP_ERR		  -101 //http���ش���
#define MISC_RETURN_ERR		-102 //http�ķ������ݴ���
#define MISC_PARAM_ERR		-103 //��������
#define MISC_ENCODE_ERR		-104 //���ܴ���

#ifdef __cplusplus
extern "C" {
#endif

long submitgrp(int ip,
				u_long ismgid,
			  u_long service,
			  char *user,
			  char *passwd,
			  char *rcvfile,
			  char *sndno,
			  enum SMSRCV rcvfmt,
			  enum SMSMSG msgfmt,
			  u_long msglen,
			  char *msg);

long submitsm(int ip,
    u_long ismgid,
	  u_long from,
	  u_long service,			  
	  char *user,
	  char *passwd,
	  char *rcvno,
	  char *sndno,
	  char *feeno,
	  enum SMSRCV rcvfmt,
	  enum SMSMSG msgfmt,
	  u_long msglen,
	  char *msg,
	  char *linkid);
	  


long submitmo(
        int ip,
			  u_long ismgid ,
			  char *rcvno,
			  char *sndno,
			  enum SMSRCV rcvfmt,
			  enum SMSMSG msgfmt,
			  u_long msglen,
			  char *msg,
			  char *linkid=NULL
			  );

#ifdef __cplusplus
}  // end of extern "C" {
#endif


#endif /* !_SMSCGI_CLNT_H */
