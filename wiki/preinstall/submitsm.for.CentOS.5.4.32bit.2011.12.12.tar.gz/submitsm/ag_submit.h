/**
 * $Id ag_submit.h v 1.0 2004/12/20 14:26:00 changhong Exp$
 *
 * Copyright 2004 Sina Mobile
 * Project: SMSD
 * Author : changhong<@staff.sina.com.cn>
 * Created: 2004/12/03
 */

#ifndef _AG_SUBMIT_H_
#define _AG_SUBMIT_H_

#include "ag_core.h"
#include "ag_http_request.h"
#include "ag_parse_result.h"

#define RPC_USR         "sms"
#define RPC_PWD         "sms"

#define AG_ERR_INVALID_RECORD 4

#ifdef __cplusplus
extern "C" {
#else
#ifndef _BOOL_DEFINED_
#define _BOOL_DEFINED_
typedef enum {false, true} bool;
#endif
#endif
/*
long submitsm(u_long from,
              u_long service,                         
              char *user,
              char *passwd,
              char *rcvno,
              char *sndno,
              char *feeno,
              enum SMSMSG msgfmt,
              u_long msglen,
              char *msg,
              char *linkid);
*/
/**
 * the main request & submit routine
 *
 * @param record: the record to be handled
 * @param fname: the record filename, if invalid, it is used as the filename
 * @param child_no: the current child number
 * @param p: apr pool to be used
 * @param s: server structure (used to retrieve server configuration)
 * @return: APR_SUCCESS if OK, else error
 */
apr_status_t ag_submit(char *record, const char *fname, int child_no,
                       apr_pool_t *p, server_rec *s);

#ifdef __cplusplus
}
#endif

#endif /* _AG_SUBMIT_H_ */
