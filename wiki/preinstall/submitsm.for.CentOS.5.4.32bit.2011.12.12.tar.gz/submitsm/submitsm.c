#include <stdio.h>
#include <string.h>

#include "smscgi.h"
#include "smsgwcgi.h"



int main(int argc, char * argv[])
{
	int ip=12;
	int gid2=353101;
	int from=3;
	int svc=400391;
	char * receiver="13810520534";
	char * sender="10659715";
	char * payer="13810520534";
	enum SMSRCV rcvfmt=RCVPNO;
	enum SMSMSG fmt=FMTEXT;
	char * buf="�������ݣ��ͷ����룺12345678";
	char * linkid="";
	int r;


	r = submitsm(
                                        ip,
                                        gid2,
                                        from,
                                        svc,
                                        RPC_USR,
                                        RPC_PWD,
                                        receiver,
                                        sender,
                                        payer,
                                        rcvfmt,
                                        fmt,
                                        strlen(buf),
                                        buf,
                                        linkid
                                );
	printf("rpcid:%d\n", r);

	return 0;
}
